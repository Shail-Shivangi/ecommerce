import React, { useState } from "react";
import { products } from "../components/Product/products";
import ProductGrid from "../components/Product/ProductGrid";
import FilterSidebar from "../components/Product/FilterSidebar";
import Pagination from "../components/Product/Pagination";

const ProductsPage = () => {
  const [filters, setFilters] = useState({});
  const [currentPage, setCurrentPage] = useState(1);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="container mx-auto p-4">
          <h1 className="text-xl font-bold">E-commerce</h1>
        </div>
      </header>

      <main className="container mx-auto py-6 flex">
        <FilterSidebar filters={filters} setFilters={setFilters} />

        <div className="flex-1">
          <ProductGrid products={products} filters={filters} />
          <Pagination
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </div>
      </main>
    </div>
  );
};

export default ProductsPage;
