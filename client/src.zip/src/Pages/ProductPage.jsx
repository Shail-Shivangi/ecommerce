import ImageGallery from "../components/ProductDetails/ImageGallery";
import HeroSection from "../components/ProductDetails/HeroSection";
import Description from "../components/ProductDetails/Description";

const ProductPage = () => {
  return (
    <>
      <div className="container mx-auto p-4 pl-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ImageGallery />
          <HeroSection />
        </div>
      </div>
      <Description />
    </>
  );
};

export default ProductPage;
