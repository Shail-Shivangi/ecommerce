import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import { BrowserRouter, Routes, Route } from "react-router-dom";

//Components
import Header from "./components/Header";
import Footer from "./components/Footer";

//pages
import Home from "./Pages/Home";

const App = () => {
  return (
    <>
      <BrowserRouter>
        {/**Header */}
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
        {/**Footer */}
        <Footer />
      </BrowserRouter>
    </>
  );
};

export default App;
