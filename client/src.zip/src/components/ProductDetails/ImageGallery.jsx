import { useState } from "react";
import { FiChevronLeft, FiChevronRight } from "react-icons/fi";

import img1 from "../../assets/image1.jpg";
import img2 from "../../assets/image2.jpg";
import img3 from "../../assets/image3.jpg";
import img4 from "../../assets/image4.jpg";

const images = [img1, img2, img3, img4];

const ImageGallery = () => {
  const [selectedImage, setSelectedImage] = useState(0);

  const handlePrev = () => {
    setSelectedImage((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setSelectedImage((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="w-full max-w-4xl mx-auto rounded-lg shadow-lg border border-gray-300 p-32">
      {/* Main Image */}
      <div className="relative">
        <img
          src={images[selectedImage]}
          alt={`Product ${selectedImage}`}
          className="w-full h-80 object-cover rounded-lg shadow-md"
        />
        {/* Left Arrow */}
        <button
          className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white border border-gray-300 rounded-full p-3 shadow-lg hover:bg-gray-100"
          onClick={handlePrev}
        >
          <FiChevronLeft className="w-6 h-6 text-gray-700" />
        </button>
        {/* Right Arrow */}
        <button
          className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white border border-gray-300 rounded-full p-3 shadow-lg hover:bg-gray-100"
          onClick={handleNext}
        >
          <FiChevronRight className="w-6 h-6 text-gray-700" />
        </button>
      </div>

      {/* Thumbnail Images */}
      <div className="flex justify-center space-x-2 mt-4">
        {images.map((img, index) => (
          <div
            key={index}
            className={`border rounded-md overflow-hidden cursor-pointer ${
              selectedImage === index ? "border-orange-500" : "border-gray-300"
            }`}
            onClick={() => setSelectedImage(index)}
          >
            <img
              src={img}
              alt={`Gallery thumbnail ${index}`}
              className="h-20 w-20 object-cover transition-transform duration-300 hover:scale-105"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;
