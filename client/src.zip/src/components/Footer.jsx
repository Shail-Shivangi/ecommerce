import { FaApple, FaGooglePlay } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-8 px-6 md:px-12">
      <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-8">
        {/* Left section with logo and contact details */}
        <div className="space-y-3 text-sm">
          <h1 className="text-xl font-bold text-orange-500">CLICON</h1>
          <p>
            Customer Supports: <br />
            <span className="text-white font-semibold">(629) 555-0129</span>
          </p>
          <p>
            4517 Washington Ave. <br />
            Manchester, Kentucky 39495
          </p>
          <p>
            <a href="mailto:info@kinbo.com" className="text-white">
              info@kinbo.com
            </a>
          </p>
        </div>

        {/* Top category section */}
        <div className="space-y-3 text-sm">
          <h2 className="text-lg font-semibold text-white">Top Category</h2>
          <ul className="space-y-2 cursor-pointer">
            <li>Computer & Laptop</li>
            <li>SmartPhone</li>
            <li>Headphone</li>
            <li className="text-yellow-500">Accessories</li>
            <li>Camera & Photo</li>
            <li>TV & Homes</li>
          </ul>
          <a href="/" className="text-yellow-500 text-sm">
            Browse All Product &rarr;
          </a>
        </div>

        {/* Quick links section */}
        <div className="space-y-3 text-sm">
          <h2 className="text-lg font-semibold text-white">Quick Links</h2>
          <ul className="space-y-2 cursor-pointer">
            <li>Shop Product</li>
            <li>Shopping Cart</li>
            <li>Wishlist</li>
            <li>Compare</li>
            <li>Track Order</li>
            <li>Customer Help</li>
            <li>About Us</li>
          </ul>
        </div>

        {/* Download app section */}
        <div className="space-y-3 text-sm">
          <h2 className="text-lg font-semibold text-white">Download App</h2>
          <div className="space-y-2">
            <a
              href="/"
              className="flex items-center bg-gray-800 hover:bg-gray-700 py-2 rounded text-white px-4"
            >
              <FaGooglePlay className="text-4xl mr-4" />
              <div className="text-left">
                <p className="text-xs">Get it now</p>
                <p className="text-sm font-bold">Google Play</p>
              </div>
            </a>
            <a
              href="/"
              className="flex items-center bg-gray-800 hover:bg-gray-700 py-2 rounded text-white px-4"
            >
              <FaApple className="text-4xl mr-4" />
              <div className="text-left">
                <p className="text-xs">Get it now</p>
                <p className="text-sm font-bold">App Store</p>
              </div>
            </a>
          </div>
        </div>

        {/* Popular tags section */}
        <div className="space-y-3 text-sm">
          <h2 className="text-lg font-semibold text-white">Popular Tag</h2>
          <div className="flex flex-wrap gap-2">
            {[
              "Game",
              "iPhone",
              "TV",
              "Asus Laptops",
              "Macbook",
              "SSD",
              "Graphics Card",
              "Power Bank",
              "Smart TV",
              "Speaker",
              "Tablet",
              "Microwave",
              "Samsung",
            ].map((tag, index) => (
              <span
                key={index}
                className="bg-gray-800 px-2 py-1 border-2 border-gray-500 text-sm rounded-lg cursor-pointer hover:bg-transparent hover:border-2 hover:border-gray-100"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-8 border-t border-gray-800 pt-4 text-center text-xs">
        Kinbo - eCommerce Template © 2021. Design by Templatecookie
      </div>
    </footer>
  );
};

export default Footer;
