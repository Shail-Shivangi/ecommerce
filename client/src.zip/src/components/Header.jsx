import { useState } from "react";
import {
  FaHeart,
  FaShoppingCart,
  FaUser,
  FaSearch,
  FaFacebookF,
  FaTwitter,
  FaPinterestP,
  FaInstagram,
  FaYoutube,
  FaChevronDown,
  FaTruck,
  FaExchangeAlt,
  FaHeadset,
  FaQuestionCircle,
} from "react-icons/fa";
import { Link } from "react-router-dom"; // Import Link from react-router-dom for routing
//import Cart from "./Cart"; // Import Cart Component

const Header = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false); // State for cart dropdown

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleCartHover = () => {
    setIsCartOpen(true); // Open cart dropdown on hover
  };

  const handleCartLeave = () => {
    setIsCartOpen(false); // Close cart dropdown when not hovering
  };

  return (
    <header className="bg-blue-900 text-white">
      {/* Top Bar */}
      <div className="bg-blue-800 py-2">
        <div className="container mx-auto flex justify-between items-center text-sm px-4">
          <div>
            <span>Welcome to Nexus_Drop online eCommerce store</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>Follow us:</span>
            <FaFacebookF className="text-white hover:text-gray-400 cursor-pointer" />
            <FaTwitter className="text-white hover:text-gray-400 cursor-pointer" />
            <FaPinterestP className="text-white hover:text-gray-400 cursor-pointer" />
            <FaInstagram className="text-white hover:text-gray-400 cursor-pointer" />
            <FaYoutube className="text-white hover:text-gray-400 cursor-pointer" />
            <span className="ml-4">Eng </span>
            <p>|</p>
            <span className="ml-1">Hindi</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto flex flex-wrap justify-between items-center py-4 px-4">
        {/* Logo */}
        <div className="text-2xl font-bold">
          <Link to="/" className="text-white">
            Nexus_Drop
          </Link>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-1/2 mt-2 md:mt-0">
          <input
            type="text"
            placeholder="Search for anything..."
            className="w-full px-10 py-2 rounded-md text-gray-700 focus:outline-none"
          />
          <FaSearch className="absolute left-3 top-3 text-gray-500" />
        </div>

        {/* Contact and Icons */}
        <div className="flex items-center space-x-6 mt-4 md:mt-0">
          <div className="flex space-x-6">
            {/* Wishlist */}
            <Link
              to="/wishlist"
              className="flex items-center space-x-1 hover:text-gray-300"
            >
              <FaHeart className="text-xl" />
            </Link>

            {/* Cart with Hover */}
            <div
              className="relative"
              onMouseEnter={handleCartHover}
              onMouseLeave={handleCartLeave}
            >
              <Link
                to="/cart"
                className="flex items-center space-x-1 hover:text-gray-300"
              >
                <FaShoppingCart className="text-xl" />
              </Link>

              {/* Cart Dropdown */}
              {isCartOpen && (
                <div className="absolute right-0 mt-2 w-full sm:w-64 md:w-80 lg:w-96 bg-white shadow-lg p-4 z-50">
                  <Cart /> {/* Render Cart Component */}
                </div>
              )}
            </div>

            {/* Profile */}
            <Link
              to="/auth"
              className="flex items-center space-x-1 hover:text-gray-300"
            >
              <FaUser className="text-xl" />
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-white shadow-md py-2">
        <div className="container mx-auto flex flex-wrap items-center justify-between space-y-4 md:space-y-0 px-4">
          {/* All Category with Dropdown */}
          <div className="relative">
            <button
              className="bg-gray-600 text-white px-4 py-2 rounded-md flex items-center"
              onClick={toggleDropdown}
            >
              All Category
              <FaChevronDown className="ml-2" />
            </button>
            {/* Dropdown Menu */}
            {isDropdownOpen && (
              <div className="absolute left-0 mt-2 w-56 bg-white shadow-lg rounded-md overflow-hidden z-10">
                <ul className="py-2">
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                  <li className="px-4 py-2 text-gray-700 hover:bg-gray-200 hover:text-gray-900 cursor-pointer">
                    Computer & Laptop
                  </li>
                </ul>
              </div>
            )}
          </div>

          {/* Menu Items with Icons */}
          <div className="flex space-x-4 md:space-x-6 text-sm text-gray-700">
            <a
              href="#"
              className="flex items-center space-x-1 hover:text-blue-700"
            >
              <FaTruck />
              <span>Track Order</span>
            </a>
            <a
              href="#"
              className="flex items-center space-x-1 hover:text-blue-700"
            >
              <FaExchangeAlt />
              <span>Compare</span>
            </a>
            <Link
              to="/support"
              className="flex items-center space-x-1 hover:text-blue-700"
            >
              <FaHeadset />
              <span>Customer Support</span>
            </Link>
            <a
              href="#"
              className="flex items-center space-x-1 hover:text-blue-700"
            >
              <FaQuestionCircle />
              <span>Need Help?</span>
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
