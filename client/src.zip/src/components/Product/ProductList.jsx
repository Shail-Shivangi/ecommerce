import  { useEffect, useState } from "react";
import { getProducts } from "../services/productService";
import ProductItem from "./ProductItem"; // Assuming ProductItem is used for smaller cards
import FeaturedCard from "./FeaturedCard"; // Assuming FeaturedCard is used for the large card

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
        setLoading(false);
      } catch (error) {
        setError("Failed to fetch products");
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  // Separate featured and smaller products
  const featuredProduct = products[0];
  const smallerProducts = products.slice(1);

  return (
    <div className="product-list">
      {featuredProduct && <FeaturedCard product={featuredProduct} />}
      <div className="smaller-products">
        {smallerProducts.map((product) => (
          <ProductItem key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductList;
